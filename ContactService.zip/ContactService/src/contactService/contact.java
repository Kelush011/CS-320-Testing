package contactService;

public class contact {
	private String contactId;
	private String firstName;
	private String lastName;
	private String phoneNum;
	private String address;
	
	public contact (String contactId, String firstName, String lastName, String phoneNum, String address) {
		//throws error if arguments are not valid
		validateContactId(contactId);
		validateFirstName(firstName);
		validateLastName(lastName);
		validatePhoneNum(phoneNum);
		validateAddress(address);
		
		//set variables to arguments
		this.contactId = contactId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNum = phoneNum;
		this.address = address;
	}
	
	//cannot update id so there will only be a getter
	public String getContactId() {
		return contactId;
	}
	//getter for first name
	public String getFirstName() {
		return firstName;
	}
	//Setter for First Name
	public void setFirstName(String firstName) {
		validateFirstName(firstName);
		this.firstName = firstName;
	}
	//getter for Last Name
	public String getLastName() {
		return lastName;
	}
	//setter for Last Name
	public void setLastName(String lastName) {
		validateLastName(lastName);
		this.lastName = lastName;
	}
	//getter for phoneNum
	public String getPhoneNum() {
		return phoneNum;
	}
	//setter
	public void setPhoneNum(String phoneNum) {
		validatePhoneNum(phoneNum);
		this.phoneNum = phoneNum;
	}
	//getter for address
	public String getAddress() {
		return address;
	}
	//setter
	public void setAddress(String address) {
		validateAddress(address);
		this.address = address;
	}
	//firstName no longer than 10 characters. cannot be null.
	private void validateFirstName (String firstName) {
		if(firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid first name");
		}
	}
	//lastName no longer than 10 characters. cannot be null.
	private void validateLastName (String lastName) {
		if(lastName == null || lastName.length() >10) {
			throw new IllegalArgumentException("Invalid last name");
		}
	}
	//phoneNum must be exactly 10 characters. cannot be null.
	private void validatePhoneNum(String phoneNum) {
		if(phoneNum == null|| phoneNum.length() != 10) {
			throw new IllegalArgumentException("Invalid phone number");
		}
	}
	//address no longer than 30 characters. cannot be null.
	private void validateAddress(String address){
		if(address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid address");
		}
	}
	}
	
	