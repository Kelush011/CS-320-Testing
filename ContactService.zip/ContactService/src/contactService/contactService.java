package contactService;

import java.util.ArrayList;

public class ContactService{
	private ArrayList<contact> contacts;
	
	//constructor
	public ContactService() {
		contacts = new ArrayList<>();
	}
	//add contacts w unique ID
	public boolean addContact(contact newContact){
		boolean contains = false;
		for (contact a : contacts) {
			if (a.getContactId().equalsIgnoreCase(newContact.getContactId()))
			{
				contains = true;
				break;
			}
		}
		if (!contains) {
			contacts.add(newContact);
			return true;}
		else {
			return false;
		}
	}
	//deletes contact using id
	public boolean deleteContact(String contactId) {
		boolean deleted = false;
		for (contact a : contacts) {
			if(a.getContactId().equalsIgnoreCase(contactId)) {
				contacts.remove(a);
				deleted = true;
				break;
			}
		}
		return deleted;
	}
	//updates contact using contact id
	public boolean updateContactFirstName(String contactId, String newFirstName) {
		boolean updated = false;
		for(contact a : contacts) {
			if (a.getContactId().equalsIgnoreCase(contactId)) {
				a.setFirstName(newFirstName);
				updated = true;
				break;
			}
		}
		return updated;
	}
	public boolean updateContactLastName(String contactId, String newLastName) {
		boolean updated = false;
		for(contact a : contacts) {
			if (a.getContactId().equalsIgnoreCase(contactId)) {
				a.setLastName(newLastName);
				updated = true;
				break;
			}
		}
		return updated;
	}
	public boolean updateContactPhoneNum(String contactId, String newPhoneNum) {
		boolean updated = false;
		for(contact a : contacts) {
			if (a.getContactId().equalsIgnoreCase(contactId)) {
				a.setPhoneNum(newPhoneNum);
				updated = true;
				break;
			}
		}
		return updated;
	}
	public boolean updateContactAddress(String contactId, String newAddress) {
		boolean updated = false;
		for(contact a : contacts) {
			if (a.getContactId().equalsIgnoreCase(contactId)) {
				a.setAddress(newAddress);
				updated = true;
				break;
			}
		}
		return updated;
	}
}