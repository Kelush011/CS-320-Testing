
package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Assertions;
import contactService.contact;
import contactService.ContactService;

public class ContactServiceTest {
	
	@Test
	@DisplayName("Add a contact to a newly instantiated Contact Service")
	public void addContact(){
		ContactService cs = new ContactService();
		contact test1 = new contact("A42197", "Kaitlyn", "Lush", "5028645215", "688 Puppy Street, Dog City");
		assertEquals(true, cs.addContact(test1));
	}
	@Test
	@DisplayName("Delete a contact")
	public void deleteContact() {
		ContactService cs = new ContactService();
		
		contact test1 = new contact("A42197", "Kaitlyn", "Lush", "5028645215", "688 Puppy Street, Dog City");
		contact test2 = new contact("B42998", "Chris", "Pape", "2704569632", "586 Rocky Road, Dog City");
		contact test3 = new contact("C45862", "Jerry", "Smith", "5485558456", "123 Outerworld Rd");
		
		cs.addContact(test1);
		cs.addContact(test2);
		cs.addContact(test3);
		
		assertEquals(true, cs.deleteContact("A42197"));
		assertEquals(false, cs.deleteContact("A42789"));
		assertEquals(false, cs.deleteContact("A42396"));
	}
	@Test
	@DisplayName("Update contacts")
	public void testUpdate() {
		ContactService cs = new ContactService();
		
		contact test1 = new contact("A42197", "Kaitlyn", "Lush", "5028645215", "688 Puppy Street, Dog City");
		contact test2 = new contact("B42998", "Chris", "Pape", "2704569632", "586 Rocky Road, Dog City");
		contact test3 = new contact("C45862", "Jerry", "Smith", "5485558456", "123 Outerworld Rd");
		
		cs.addContact(test1);
		cs.addContact(test2);
		cs.addContact(test3);
		
		assertEquals(true,cs.updateContactFirstName("C45862", "Jeremiah"));
		assertEquals(false,cs.updateContactFirstName("C48652", "Jeremiah"));
	}

	}

