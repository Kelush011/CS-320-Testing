package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import contactService.contact;

public class contactTest {
	@Test
	@DisplayName("Create a contact with valid arguments and get values from newly created contact")
	void testContact() {
		contact contact = new contact("A42197", "Kaitlyn", "Lush", "5028645215", "688 Puppy Street, Dog City");
		assertTrue(contact.getContactId().equals("A42197"));
		assertTrue(contact.getFirstName().equals("Kaitlyn"));
		assertTrue(contact.getLastName().equals("Lush"));
		assertTrue(contact.getPhoneNum().equals("5028645215"));
		assertTrue(contact.getAddress().equals("688 Puppy Street, Dog City"));
	}
	@Test
	@DisplayName("Create a contact with a null Contact ID")
	void testContactNullId() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new contact(null, "Kaitlyn", "Lush", "5028645215", "688 Puppy Street, Dog City");
		});
	}
	@Test
	@DisplayName("Create a contact with a contact id longer than 10 characters")
	void testContactIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new contact("A4219789765", "Kaitlyn", "Lush", "5028645215", "688 Puppy Street, Dog City");
		});
	}
	@Test
	@DisplayName("Create a contact with a first name longer than 10 characters")
	void testContactFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new contact("A42197", "Kaitalionate", "Lush", "5028645215", "688 Puppy Street, Dog City");
		});
		}
	@Test
	@DisplayName("Create First Name with a null argument")
	void testContactCreateFirstNameNull() {
		contact contact = new contact("A42197", "Kaitlyn", "Lush", "5028645215", "688 Puppy Street, Dog City");
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			contact.setFirstName(null);
		});
	}
	@Test
	@DisplayName("Update First Name")
	void testContactUpdateFirstName() {
		contact contact = new contact("A42197", "Kaitlyn", "Lush", "5028645215", "688 Puppy Street, Dog City");
		contact.setFirstName("Lilah");
		assertTrue(contact.getFirstName().equals("Lilah"));
	}
	@Test
	@DisplayName("Update First Name with a string longer than 10 characters")
	void testContactUpdateFirstNameTooLong() {
		contact contact = new contact("A42197", "Kaitlyn", "Lush", "5028645215", "688 Puppy Street, Dog City");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			contact.setFirstName("Christianna");
		});
	}
	@Test
	@DisplayName("Update First Name with a null Argument")
	void testContactUpdateFirstNameNull() {
		contact contact = new contact("A42197", "Kaitlyn", "Lush", "5028645215", "688 Puppy Street, Dog City");
	Assertions.assertThrows(IllegalArgumentException.class,()->{
		contact.setFirstName(null);
	});
	}
	@Test
	@DisplayName("Create a contact with Last Name longer than 10 characters")
			void testContactLastNameTooLong() {
				Assertions.assertThrows(IllegalArgumentException.class,()->{
					new contact("A42197", "Kaitlyn", "Lushingtone", "5028645215", "688 Puppy Street, Dog City");
				});
			}
			
	@Test
	@DisplayName("update a contact with a null Last Name")
	void testContactUpdateLastNameNull() {
		contact contact = new contact("A42197", "Kaitlyn", "Lush", "5028645215", "688 Puppy Street, Dog City");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			contact.setLastName(null);
		});
	}
	@Test
	@DisplayName("Update Last Name")
	void testContactUpdateLastName() {
		contact contact = new contact("A42197", "Kaitlyn", "Lush", "5028645215", "688 Puppy Street, Dog City");
		contact.setLastName("Pape");
		assertTrue(contact.getLastName().equals("Pape"));
	}
	@Test
	@DisplayName("Create a contact with a null lastName")
	void testContactNullLastName() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new contact("A42197", "Kaitlyn", "null", "5028645215", "688 Puppy Street, Dog City");
		});
	}
	@Test
	@DisplayName("Create a contact with a phone number that is less than 10 digits")
	void testContactPhoneNumTooShort() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new contact("A42197", "Kaitlyn", "Lush", "8645215", "688 Puppy Street, Dog City");
		});
		}
	@Test
	@DisplayName("Create a contact with a phone number that is too long")
		void testContactPhoneTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new contact("A42197", "Kaitlyn", "Lush", "50286452155", "688 Puppy Street, Dog City");
		});
	}
	@Test
	@DisplayName("Update Phone number")
	void testContactUpdatePhone() {
		contact contact = new contact("A42197", "Kaitlyn", "Lush", "5028645215", "688 Puppy Street, Dog City");
		contact.setPhoneNum("1234567890");
		assertTrue(contact.getPhoneNum().equals("1234567890"));
	}
	@Test
	@DisplayName("create a contact with address longer than 30 characters")
	void testContactAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new contact("A42197", "Kaitlyn", "Lush", "5028645215", "688 Puppy Street, Dog City, Kentucky");
			
		});
		
	}
	@Test
	@DisplayName("create contact with null address")
	void testContactAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new contact("A42197", "Kaitlyn", "Lush", "5028645215", "null");
		});
	}
	@Test
	@DisplayName("Update address")
	void testCotactUpdateAddress() {
		contact contact = new contact("A42197", "Kaitlyn", "Lush", "5028645215", "688 Puppy Street, Dog City");
			Assertions.assertThrows(IllegalArgumentException.class,()->{
				contact.setAddress("415 valleywood way, happyville");
			});
	}
	@Test
	@DisplayName("Update address longer than 30 characters")
	void testContactUpdateAddressTooLong() {
		contact contact = new contact("A42197", "Kaitlyn", "Lush", "5028645215", "688 Puppy Street, Dog City");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			contact.setAddress("415 happywood road, seaville, USA");
		});
	}
	@Test
	@DisplayName("Update address with null argument")
	void testContactUpdateAddressNull() {
		contact contact = new contact("A42197", "Kaitlyn", "Lush", "5028645215", "688 Puppy Street, Dog City");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			contact.setAddress(null);
		});
	}
}
					
